package core;

public enum  CoresEnum {
    WHITE,
    RED,
    GREEN,
    BLUE
}
