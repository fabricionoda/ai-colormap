package exceptions;

public class ColoreGrafoException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ColoreGrafoException(String mensagem) {
		super(mensagem);
	}

}
