package exceptions;

public class ImpossivelColorirBackTrackRequiredException extends
		ImpossivelColorirException {
	
	private static final long serialVersionUID = 1L;

	public ImpossivelColorirBackTrackRequiredException(String message) {
		super(message);
	}

}
