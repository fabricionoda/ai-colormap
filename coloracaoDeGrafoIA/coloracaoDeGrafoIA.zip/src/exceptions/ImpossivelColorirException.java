package exceptions;

public class ImpossivelColorirException extends ColoreGrafoException {
	
	private static final long serialVersionUID = 1L;

	public ImpossivelColorirException(String message) {
		super(message);
	}

}
