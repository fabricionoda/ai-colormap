package main;

import core.ColoreGrafoBuscaEmLargura;
import core.GrafoNo;

public class Main {
	
    public static void main(String[] args) {

    	GrafoNo noInicial;
        try {    	
            noInicial = CarregaArquivoGrafo.geraGrafoDoArquivo("C:/Users/shiga/Desktop/grafo.txt");

        	ColoreGrafoBuscaEmLargura coloreGrafo = new ColoreGrafoBuscaEmLargura();
        	coloreGrafo.colore(noInicial);
        } catch(Exception e) {
        	System.out.println("FATAL ERROR: " + e.getMessage());
        }
 
    }

}
